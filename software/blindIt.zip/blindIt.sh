#!/bin/bash

# blindIt v0.2
# Copyright (C) 2015 Martin Abreu Zavaleta
# 
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

usage="\n
$(basename "$0") [option] -- blinds or unblinds every file in a folder\n
\n
Options:\n \n
-b --blind\t     blinds every file in current folder\n
-u --unblind\t   assigns every file in current folder its original name\n
-c --clear\t     deletes auxiliary files [DO NOT USE BEFORE UNBLINDING]\n
-h --help\t       displays this message\n
\n
Examples:\n \n
$(basename "$0") --blind\n
$(basename "$0") -u\n
"

prog ()
{
FLOOR=1000
number=0
while [ $number -le $FLOOR ]
	do
	number=$RANDOM
done
if grep -q $number .random; then
	prog
else
	echo $number >> .random
fi
return 0
}

clean_option () {
read answer
	case $answer in
		Y | y | YES | yes | Yes )	flush
									;;
		* )							echo "Auxiliary files unchanged. Delete manually before blinding again."
									exit 1
	esac
}

blinder () {
if [ ! -f .files  ]
	then
		ls | cat > .files
	else
		echo ""
		echo "WARNING: DO NOT BLIND AGAIN BEFORE UNBLINDING. YOU MAY NOT BE ABLE TO RECOVER THE ORIGINAL NAMES OF YOUR FILES."
		echo ""
		echo "Auxiliary files found. You must clean before proceeding. Clean now? (Y/n) [ENTER after input]"
		clean_option
		blinder
fi
FILES=$(wc -l < .files)
touch .random
RAND=$(wc -l < .random)
while [ "$RAND" -lt "$FILES" ]
	do
		prog
	(( RAND = RAND + 1 ))
done
count=1
file_count=0
#folder_count=0
while [ "$count" -le "$FILES" ]
	do
		name=$(sed ''$count'q;d' .files)
		ext=${name##*.}
		new_name=$(sed ''$count'q;d' .random).$ext
		if [ -f "$name" ]; then 
#			echo "the count is $count"
#			ls
#			echo $name
#			echo $ext
#			echo $new_name
#			echo "from $name to $new_name" >> .manifestb
			mv "$name" "$new_name"
#			ls
			((count = count + 1))
			((file_count = file_count + 1))
#			echo "the count is $count"
		else
#			echo "skipping line number $count"
			((count = count + 1))
#			((folder_count = folder_count + 1))
		fi
done
echo "$file_count files anonymized"
#echo "$folder_count folders unchanged"
exit
}

unblinder () {
if [ ! -f .files ]
	then
		echo "ERROR: No auxiliary files found."
		exit
fi
FILES=$(wc -l < .files)
RAND=$(wc -l < .random)
count=1
file_count=0
#folder_count=0
while [ "$count" -le "$RAND" ]
	do
		name=$(sed ''$count'q;d' .files)
		ext=${name##*.}
		new_name=$(sed ''$count'q;d' .random).$ext
		if [ -f "$new_name" ]; then 
#			echo "the count is $count"
#			ls
#			echo $name
#			echo $ext
#			echo $new_name
			mv "$new_name" "$name"
#			echo "from $new_name to $name" >> .manifestu
#			ls
			((count = count + 1))
			((file_count = file_count + 1))
#			echo "the count is $count"
		else
#			echo "missing $new_name"
#			echo "skipping line number $count"
			((count = count + 1))
#			((folder_count = folder_count + 1))
		fi
done
echo "$file_count files identified"
#echo "$folder_count folders unchanged"
echo ""
echo "Deleting auxiliary files is recommended once you're satisfied with file identification. Would you like to delete auxiliary files now? (Y/n) [ENTER after input]"
clean_option
#exit
}

flush () {
rm .files .random
echo "Auxiliary files deleted"
return 0
}

# main
if [ "$1" == "" ]; then
	echo -e $usage
	exit
else
	case $1 in
		-b | --blind )		blinder
							exit
							;;
		-u | --unblind )	unblinder
							exit
							;;
		-c | --clear )		flush	
							exit
							;;
		-h | --help )		echo -e $usage
							exit
							;;
		* )					echo -e $usage
							exit
	esac
fi
							


