#!/bin/bash
chmod +x blindIt.sh
sudo cp blindIt.sh /usr/local/bin
sudo ln /usr/local/bin/blindIt.sh /usr/local/bin/blindIt
blindIt
